SP Artistry Static Frontend Page

Files included:
- index.html
- assets/ folder with the replaced about and gallery images

How to host free:
1. Upload the full folder contents to Netlify Drop, GitHub Pages, Vercel, Firebase Hosting, or any static web host.
2. Keep index.html and assets/ in the same directory.
3. Do not rename the assets folder unless you update the image paths in index.html.

Changed image mapping:
- About frame near "Beauty Designed Around You": assets/about.jpg
- Hero background: assets/hero.jpg
- Gallery images: assets/gallery-1.jpg to assets/gallery-6.jpg
